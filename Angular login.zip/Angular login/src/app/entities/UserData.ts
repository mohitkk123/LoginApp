export class UserData{
    id:number;
    email:string;
    password:string;
    firstName:string;
    lastName:string;
    resetToken:string;
}