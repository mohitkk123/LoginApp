export class PasswordData{
    token:string;
    password:string;
    confirmPassword:string;
}