import { Component, OnInit } from '@angular/core';
import { LoginServiceService } from '../../services/login-service.service';
import { UserCredential } from '../../entities/UserCredential';
import { UserData } from '../../entities/UserData';
import { Router } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  result:UserData;
  success:boolean=false;
  errorLog:String;
  credential:UserCredential=new UserCredential();
  

  constructor( private lService : LoginServiceService,private router:Router) { }

  ngOnInit(): void {
  }

  loginUser(){
    this.errorLog=undefined;
    this.lService.loginUser(this.credential).subscribe(data=>{
      this.result=data;
      this.errorLog=undefined;
      this.success=true;

      this.router.navigateByUrl("home");

      
    },
    error=>{
    this.errorLog=error.error;
    });

  }

  log(formsearch){
    console.log(formsearch);
  }

}
