import { Component, OnInit } from '@angular/core';
import { Router } from '../../../../node_modules/@angular/router';
import { LoginServiceService } from '../../services/login-service.service';
import { PasswordData } from '../../entities/PasswordData';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  passData:PasswordData=new PasswordData();
  success:boolean=false;
  errorLog:String;
  result:string;
  constructor(private lService : LoginServiceService,private router:Router) { }

  ngOnInit(): void {
  }

  changePassword(){
     if(this.passData.password==this.passData.confirmPassword){
      this.errorLog=undefined;
      this.lService.changePassword(this.passData).subscribe(data=>{
        this.result=data;
        this.errorLog=undefined;
        this.success=true;
  
        this.router.navigateByUrl("/login");
  
        
      },
      error=>{
      this.errorLog=error.error;
      });
     }else{
       this.errorLog="password do not match !";
     }
  }

}
