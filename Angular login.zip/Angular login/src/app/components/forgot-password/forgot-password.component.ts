import { Component, OnInit } from '@angular/core';
import { Router } from '../../../../node_modules/@angular/router';
import { LoginServiceService } from '../../services/login-service.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  result:string;
  success:boolean=false;
  errorLog:string;
  email:string="";
  loading:boolean=false;
  buttonVisible:boolean=true;
  
  constructor(private router:Router,private lService:LoginServiceService) { }

  ngOnInit(): void {
  }

  searchEmail(){
    this.errorLog=undefined;
    this.loading=true;
    this.buttonVisible=false;
   this.lService.searchEmail(this.email).subscribe(data=>{
    this.loading=false;
    this.buttonVisible=true;
    this.result=data;
    this.errorLog=undefined;
    this.router.navigateByUrl("/changePassword");
  },error=>{
    this.loading=false;
    this.buttonVisible=true;
    this.errorLog=error.error;
   });

   console.log(this.errorLog);
  }

}
