import { Injectable } from '@angular/core';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';
import { UserCredential } from '../entities/UserCredential';
import { PasswordData } from '../entities/PasswordData';

@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {

  constructor(private http:HttpClient) { }

  loginUser(credential:UserCredential):Observable<any>{
    return this.http.post("http://localhost:9000/Login",credential,{responseType:"text"});
  }

  searchEmail(email:string):Observable<any>{
    return this.http.get(`http://localhost:9000/forgotPassword/${email}`);
  }


  changePassword(data:PasswordData):Observable<any>{
    return this.http.post("http://localhost:9000/updatePassword",data,{responseType:"text"});
  }
}
