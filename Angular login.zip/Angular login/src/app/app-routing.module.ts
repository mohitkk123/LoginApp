import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { HomeComponent } from './components/home/home.component';
import { ErrorComponent } from './components/error/error.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';


const routes: Routes = [ { path: '', component: LoginComponent },
  
{ path: 'login', component: LoginComponent },
{ path: 'forgotPassword', component: ForgotPasswordComponent },
{ path: 'home', component: HomeComponent },
{ path: 'changePassword', component: ChangePasswordComponent },



{ path: '**', component: ErrorComponent
 }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
